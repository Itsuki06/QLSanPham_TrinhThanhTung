package Database;

import java.sql.*;
import javax.swing.JOptionPane;

public class Connect {
    public static Connection getConnection() throws SQLException {
        try {
            String userName = "sa";
            String password = "123456789h";
            String url = "jdbc:sqlserver://localhost:1433;databasename=QLSanPham;encrypt=true;trustServerCertificate=true;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = java.sql.DriverManager.getConnection(url, userName, password);
            return conn;
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Failed to Connect to Database!", "Announcement", 1);            
        }
        return null;
    }
}
