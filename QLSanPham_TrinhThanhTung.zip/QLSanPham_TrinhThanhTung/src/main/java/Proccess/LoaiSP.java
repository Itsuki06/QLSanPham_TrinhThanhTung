/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proccess;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Database.Connect;

public class LoaiSP {
    public Connect cn = new Connect();

    private String maLoai;
    private String tenLoai;

    public LoaiSP() {
    }

    public LoaiSP(String maLoai, String tenLoai) {
        this.maLoai = maLoai;
        this.tenLoai = tenLoai;
    }

    public String getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(String maLoai) {
        this.maLoai = maLoai;
    }

    public String getTenLoai() {
        return tenLoai;
    }

    public void setTenLoai(String tenLoai) {
        this.tenLoai = tenLoai;
    }
    
    //Truy van tat ca du lieu trong Bang LoaiSP:
    public List<LoaiSP> GetLoaiSP() throws SQLException {
        List<LoaiSP> list = new ArrayList<>();
        String sql = "SELECT * FROM LoaiSP";
        
        // Dùng try-with-resources để tự động đóng các tài nguyên sau khi sử dụng:
        try (// Tạo một kết nối Connection với cơ sở dữ liệu
                Connection conn = cn.getConnection(); 
             // Chuẩn bị truy vấn SQL từ sql, giúp bảo vệ khỏi SQL Injection.
                PreparedStatement pst = conn.prepareStatement(sql);
             // Thực thi truy vấn và trả về một ResultSet, chứa các dòng kết quả từ bảng LoaiSP.
                ResultSet rs = pst.executeQuery()) {
            
            while (rs.next()) {
                LoaiSP lsp = new LoaiSP();
                // Lấy dữ liệu từ cột MaLoai và TenLoai của dòng hiện tại trong ResultSet và gán vào đối tượng loaiSP.
                lsp.setMaLoai(rs.getString("MaLoai"));
                lsp.setTenLoai(rs.getString("TenLoai"));
                // Thêm đối tượng loaiSP vào danh sách list
                list.add(lsp);
            }
        }        
        return list;
    }
    
    //Truy van cac dong du lieu trong Bang LoaiSP theo MaLoai:
    public LoaiSP GetLoaiSP(String ml) throws SQLException {
        LoaiSP lsp = null;
        String sql = "SELECT * FROM LoaiSP WHERE MaLoai = ?";
        
        try (Connection conn = cn.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, ml); // Gán giá trị của ml vào tham số đầu tiên ?.
            try (ResultSet rs = pst.executeQuery()) {                
                // Nếu có dữ liệu, khởi tạo đối tượng LoaiSP và gán giá trị từ ResultSet vào các thuộc tính MaLoai và TenLoai.
                if (rs.next()) { 
                    lsp = new LoaiSP();
                    lsp.setMaLoai(rs.getString("MaLoai"));
                    lsp.setTenLoai(rs.getString("TenLoai"));
                }
            }
        }
        return lsp;
    }
    
    //Them moi 1 dong du lieu vao Bang LoaiSP:
    public boolean InsertData(LoaiSP obj) throws SQLException {
        String sql = "INSERT INTO LoaiSP (MaLoai, TenLoai) VALUES (?, ?)";
        
        try (Connection conn = cn.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, obj.getMaLoai());
            pst.setString(2, obj.getTenLoai());
            
            //Thực thi truy vấn và trả về true nếu số dòng bị ảnh hưởng lớn hơn 0, nghĩa là đã thêm thành công.
            return pst.executeUpdate() > 0;
        }
    }
    
    //Chinh sua 1 dong du lieu trong Bang LoaiSP:
    public boolean EditData(LoaiSP obj) throws SQLException {
        String sql = "UPDATE LoaiSP SET TenLoai = ? WHERE MaLoai = ?";
        
        try (Connection conn = cn.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, getMaLoai());
            pst.setString(2, getTenLoai());
            
            //Thực thi truy vấn và trả về true nếu số dòng bị ảnh hưởng lớn hơn 0, nghĩa là đã thêm thành công.
            return pst.executeUpdate() > 0;
        }
    }
    
    //Xoa 1 dong du lieu trong Bang LoaiSP:
    public boolean DeleteData(String ml) throws SQLException {
        String sql = "DELETE FROM LoaiSP WHERE MaLoai = ?";
        
        try (Connection conn = cn.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, ml);
            return pst.executeUpdate() > 0;
        }
    }
}
